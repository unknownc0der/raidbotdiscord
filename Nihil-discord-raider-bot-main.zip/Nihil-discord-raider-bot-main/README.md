Comandos:
/muerte (nombre del server [opcional]) (foto del server [opcional])


este comando borra todos los canales y opcionalmente pasa como parametro el nombre que quieras para cambiarle el servidor y una foto para ponerla de icono al servidor

![image](https://user-images.githubusercontent.com/52175067/192129587-386d4c58-90a1-4c39-a3dd-084c3d80164a.png)

/spam (cantidad de canales [requerido]) (nombre de canal [requerido]) (mensaje a spamear[requerido])


Crea cuantos canales sean especificados, con el nombre especificado y pinguea cada milisegundo con un mensaje que se especifique

![image](https://user-images.githubusercontent.com/52175067/192129510-295e53eb-10c0-4d52-be06-320bce8c8e02.png)

Configuracion:
Para configurar el bot debes introducir tu token y el id de tu bot en el archivo config.json

![image](https://user-images.githubusercontent.com/52175067/192129634-5e890a01-5e05-413f-8601-281ed6e873eb.png)

